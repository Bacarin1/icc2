/*
	nome: Gabriel Bacarin #10873351
	SCC0201 - ICC 2
	[Exercício 3] Busca Indexada em Lista Encadeada
*/
typedef struct palavra palavra;

struct palavra {
	char header;
	char *nome;
	int tamNome;
	palavra *prox;
};

typedef struct lista {
	int versao;
	palavra *inicio;
} lst;

typedef struct vetor {
	int versao;
	char header;
	palavra *primeiraPalavra;
} vetor;

lst *criarLista();
palavra *criarPalavra(char *nome, char header, int tamNome);
void adicionarPalavra(lst *l, char *nome, char header, int tamNome);
void imprimirLista(lst *l);
int atualizarVetor(lst *l, vetor *v);
int buscarPalavra(lst *l, vetor *v, char *buscar);
void imprimir3(lst *l);
void liberarLista(lst *l);