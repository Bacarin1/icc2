/*
	nome: Gabriel Bacarin #10873351
	SCC0201 - ICC 2
	[Exercício 3] Busca Indexada em Lista Encadeada
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"lista.h"

/*função que coloca no vetor o alfabeto em cada header*/
void popularVetor(vetor *vec) {

	int letra = 'a';
	for(int i = 0; i < 26; i++) {
		vec[i].header = letra;
		letra++;
	}
}

/*lê uma palavra de um arquivo, até o \n ou EOF. Se o arquivo for nulo, lê do stdin
retorna a palavra lida*/
char *lerPalavra(FILE *fonte, int *isEOF) {
	char entrada;
	int tamanho = 0;
	char *palavra = malloc(0 * sizeof(char));
	do {
		if(fonte == NULL)
			entrada = fgetc(stdin);
		else
			entrada = fgetc(fonte);

		if(entrada == '\r')
			continue;

		tamanho = tamanho + 1;
		palavra = realloc(palavra, tamanho * sizeof(char)); // vai aumentar o tamanho da alocação em 1
		if(palavra != NULL) { // caso a alocação tenha sido bem sucedida
			if(entrada == '\n' || entrada == EOF) {
				palavra[tamanho - 1] = '\0';				
			}
			else {
				palavra[tamanho - 1] = entrada;
			}

		}
		else { //realloc não funcionou
			printf("Task failed successfully!\n");
			free(palavra);
			exit(1);
		}
	} while(entrada != '\n' && entrada != EOF);

	if(entrada == EOF) // se é fim de arquivo, muda a flag
		*isEOF = 1;

	return palavra;	//retorna a palavra
}

/*lê o nome de um arquivo, abre ele, lê seu conteúdo e adiciona palavra por palavra*/
void lerEAdicionar(lst *lista) {
	int isEOF = 0;
	char *nomeArq = lerPalavra(NULL, &isEOF);	

	//printf("%s\n", nomeArq);
	FILE *arquivo = fopen(nomeArq, "r");
	if(arquivo == NULL) {
		printf("ERRO\n");
		exit(1);
	}

	do {
		char *palavra = lerPalavra(arquivo, &isEOF);
		adicionarPalavra(lista, palavra, palavra[0], strlen(palavra));
		free(palavra);

		if(isEOF == 1)
			break;
	} while(isEOF != 1);

	fclose(arquivo);
	free(nomeArq);
}

/*a main vai ler os comandos e executar uma das 3 coisas possíveis, até que se chegue no comando 0*/
int main() {
	int comando;
	lst *lista = criarLista();
	vetor *vec = malloc(26 * sizeof(vetor)); // criando o vetor de índices
	popularVetor(vec);
	vec[0].versao = -1; //iniciando sua versão

	do {
		scanf("%d ", &comando);
		if(comando == 1) { //ler do arquivo
			lerEAdicionar(lista);
			//imprimirLista(lista);
			imprimir3(lista);
		}
		if(comando == 2) { //atualizar vetor
			int qtd = atualizarVetor(lista, vec);
			vec[0].versao = lista->versao;
			printf("%d\n", qtd);
		}
		if(comando == 3) { //buscar palavra
			int qtd = 0;
			char *buscar = lerPalavra(NULL, &qtd);
			if(lista->inicio == NULL) {
				printf("Vetor de indices nao atualizado.\n");
			}
			else if(vec[0].versao != lista->versao) {
				printf("Vetor de indices nao atualizado.\n");
			}
			else {
				qtd = 0; // qtd é a quantidade de vezes que o percorre acessa o próximo
				qtd = buscarPalavra(lista, vec, buscar);
				if(qtd == -1) {
					printf("Palavra nao existe na lista.\n");
				}
				else {
					printf("%d\n", qtd);
				}
				
			}
			free(buscar);
		}

	} while(comando != 0);

	// desalocando memória
	liberarLista(lista);
	free(vec);

	return 0;
}