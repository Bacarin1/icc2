/*
	nome: Gabriel Bacarin #10873351
	SCC0201 - ICC 2
	[Exercício 3] Busca Indexada em Lista Encadeada
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"lista.h"

/*cria uma lista vazia e retorna ela*/
lst *criarLista() {
	lst *l = malloc(sizeof(lst));
	l->inicio = NULL;
	l->versao = 0;

	return l;
}

/*cria uma palavra e preenche ela, retorna ela preenchida*/
palavra *criarPalavra(char *nome, char header, int tamNome) {
	palavra *p = malloc(sizeof(palavra));
	p->nome = malloc(tamNome * sizeof(char));

	p->header = header;
	strcpy(p->nome, nome);
	p->tamNome = tamNome;
	p->prox = NULL;

	return p;
}

/*adiciona uma palavra na lista no lugar certo*/
void adicionarPalavra(lst *l, char *nome, char header, int tamNome) {
	palavra *percorre = l->inicio;
	palavra *ant = NULL;

	while(percorre != NULL && percorre->header < header) {
		ant = percorre;
		percorre = percorre->prox;
	}

	palavra *inserir = criarPalavra(nome, header, tamNome);

	if(percorre == NULL) {
		if(ant == NULL) { // primeira inserção
			l->inicio = inserir;
		}
		else { // inserindo no final da lista
			ant->prox = inserir;
		}
	}
	else {
		if(ant == NULL) { //inserindo no começo da lista
			inserir->prox = l->inicio;
			l->inicio = inserir;
		}
		else { //inserindo no meio da lista
			inserir->prox = percorre;
			ant->prox = inserir;
		}
	}

	l->versao++; // aumenta a versão da lista
}

/*imprime a lista inteira*/
void imprimirLista(lst *l) {
	palavra *percorre = l->inicio;
	while(percorre != NULL) {
		printf("%s\n", percorre->nome);
		percorre = percorre->prox;
	}
}

/*função que atualiza o vetor conforme a especificação*/
int atualizarVetor(lst *l, vetor *v) {
	int qtd = 0; // qtd é a quantidade de índices que apontam pra uma palavra após atualizar
	palavra *percorre = l->inicio;
	for(int i = 0; i < 26; i++) {
		while(percorre != NULL && percorre->header < v[i].header) {
			percorre = percorre->prox;
		}
		if(percorre != NULL) {
			if(percorre->header == v[i].header) {
				v[i].primeiraPalavra = percorre;
				qtd++;
				continue;
			}
		}
		if(percorre == NULL)
			return qtd;		
	}
	return qtd;
}

/*procura uma palavra, primeiro apontando para a da mesma letra no vetor e depois
indo uma por uma até encontrar ou não encontrar*/
int buscarPalavra(lst *l, vetor *v, char *buscar) {
	palavra *percorre = NULL;
	int qtd = 0;

	for(int i = 0; i < 26; i++) {
		if(v[i].header == buscar[0]) {
			percorre = v[i].primeiraPalavra;
		}
	}

	if(percorre == NULL) {
		return -1;
	}

	while(percorre != NULL && percorre->header == buscar[0]) {
		if(strcmp(percorre->nome, buscar) == 0) {
			return qtd;
		}
		percorre = percorre->prox;
		qtd++;
	}

	return -1;
}

/*imprime os 3 primeiros nós da lista*/
void imprimir3(lst *l) {
	palavra *percorre = l->inicio;
	int i = 0;

	while(i < 3) {
		if(percorre != NULL) {
			printf("%s\n", percorre->nome);
			percorre = percorre->prox;
		}
		i++;
	}
}

/*desaloca memória*/
void liberarLista(lst *l) {
	palavra *percorre = l->inicio;

	while(percorre != NULL) {
		free(percorre->nome);
		l->inicio = percorre->prox;
		free(percorre);
		percorre = l->inicio;
	}

	free(l);
}