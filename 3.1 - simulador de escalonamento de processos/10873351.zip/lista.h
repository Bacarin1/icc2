typedef struct node proc;

struct node {
	int cod;
	int tempoi;
	int restante;
	int prioridade;
	int quantuns;
	proc *ant, *prox;
};

typedef struct lista {
	int maxPrioridade;
	int ciclo;
	proc *ini, *fim;
} lst;

lst *novaLista();
void inserirProcesso(lst *l, int cod, int tempoi, int restante, int prioridade);
void imprimirLista(lst *l);
void rodarSimulacao(lst *l);
void limparLista(lst *l);