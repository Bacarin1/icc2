/*Gabriel Bacarin, 10873351, ICC 2 Trabalho 3*/
#include<stdio.h>
#include<stdlib.h>
#include"lista.h"

/*função que cria uma nova lista e retorna o endereço dela*/
lst *novaLista() {
	lst *lista = malloc(sizeof(lst));
	lista->maxPrioridade = 0;
	lista->ciclo = 1;
	lista->ini = NULL;
	lista->fim = NULL;

	return lista;
}

/*Dada uma lista e um código, verifica se ele já existe
caso exista retorna 1, caso contrário retorna 0*/
int procurarCodigo(lst *l, int cod) {	
	proc *node = l->ini;
	if(node == NULL) {
		return 0;
	}

	do {
		if(cod == node->cod)
			return 1;
		node = node->prox;
	} while(node != NULL);

	return 0;
}

/*função que preenche um novo processo com as informações
fornecidas e retorna ele*/
proc *criarProcesso(int cod, int tempoi, int restante, int prioridade) {
	proc *aux = malloc(sizeof(proc));

	aux->cod = cod;
	aux->tempoi = tempoi;
	aux->restante = restante;
	aux->prioridade = prioridade;
	aux->quantuns = 0;

	aux->ant = NULL;
	aux->prox = NULL;

	return aux;
}

/*Função que insere um processo em uma lista, analisando
onde inseri-lo para sempre manter a lista ordenada  em ordem
decrescente de prioridade*/
void inserirProcesso(lst *l, int cod, int tempoi, int restante, int prioridade) {
	// caso o código seja repetido, vai editar o código até o
	// próximo disponível
	int codExiste = procurarCodigo(l, cod);

	while(codExiste == 1) {
		cod++;
		codExiste = procurarCodigo(l, cod);
	}

	proc *prev = NULL;
	proc *aux = l->ini;

	if(aux == NULL) { //primeira inserção da lista
		aux = criarProcesso(cod, tempoi, restante, prioridade);
		l->ini = aux;
		l->fim = aux;
		l->maxPrioridade = prioridade;
		return;
	}

	// vai percorrer a lista até o aux apontar para a entrada
	// que ficará depois da inserção e o prev apontar para a
	// entrada que ficará antes da inserção
	while(prioridade <= aux->prioridade) {
		if(prioridade == aux->prioridade) { // caso a diferenciação seja por ordem de código
			if(cod < aux->cod)
				break;
		}
		prev = aux;
		aux = aux->prox;
		if(aux == NULL) { // chegou ao fim da lista
			break;
		}
	}

	proc *inserir = criarProcesso(cod, tempoi, restante, prioridade);

	if(prev == NULL) { //vai inseir no começo da lista
		l->ini = inserir;
		inserir->prox = aux;
		aux->ant = inserir;
	}
	// caso contrário vai inserir logo antes do aux
	else {
		prev->prox = inserir;
		inserir->ant = prev;
		inserir->prox = aux;
		if(aux != NULL)
			aux->ant = inserir;
		else
			l->fim = inserir;
	}
}

// Função que imprime a lista dada
void imprimirLista(lst *l) {
	proc *percorre = l->ini;

	printf("\n");
	while(percorre != NULL) {
		printf("%d %d %d %d\n", percorre->cod, percorre->tempoi, percorre->restante, percorre->prioridade);
		percorre = percorre->prox;
	}
}

//verifica se falta terminar algum processo
// se faltar retorna 0, caso contrário retorna 1
int verificaStatus(lst *l) {
	proc *percorre = l->ini;

	while(percorre != NULL) {
		if(percorre->restante != 0)
			return 0;
		percorre = percorre->prox;
	}

	return 1;
}


// Função que verifica se em determinado tempo algum processo
// com prioridade mais alta que o processo atual deve ser executado
// retorna 1 se isso acontece, e 0 caso contrário
int verificaSeEntrouProcesso(lst *l, int tempo, int prioridade) {
	proc *percorre = l->ini;

	while(percorre != NULL) {
		if(percorre->tempoi == tempo && percorre->prioridade >= prioridade)
			return 1;
		percorre = percorre->prox;
	}
	return 0;
}

// Função que roda a simulação em uma lista conforme o especificado
void rodarSimulacao(lst *l) {
	int acabou = verificaStatus(l); // variável que controla o loop
	int quantum = 0, tempo = 1;
	while(acabou != 1) { // vai percorrer a lista
		proc *percorre = l->ini;
		while(percorre != NULL) {
			if(percorre->tempoi <= tempo && percorre->restante > 0) { //verifica se processo será executado
				//executando processo
				percorre->restante = percorre->restante - 1;
				percorre->quantuns = percorre->quantuns + 1;
				quantum++;

				if(percorre->restante == 0) { // se o processo acabou imprime ele
					printf("%d %d", percorre->cod, quantum);
					acabou = verificaStatus(l); // verifica se foi o último processo
					if(acabou != 1)
						printf("\n");
				}

				// incrementa o tempo e verifica se no tempo
				// atual algum processo de prioridade mais alta
				// que o percorre entrou na lista

				// caso tenha entrado, o programa vai percorrer
				// a lista novamente desde o início
				// caso contrário, ele continua para o próximo processo
				tempo++;
				if(verificaSeEntrouProcesso(l, tempo, percorre->prioridade) == 1)
					break;
			}
			percorre = percorre->prox;
		}
	}
}

// Função que desaloca a memória alocada
void limparLista(lst *l) {
	proc *aux = l->ini;

	while(aux != NULL) {
		l->ini = l->ini->prox;
		free(aux);
		aux = l->ini;
	}

	free(l);
}