/*
	Nome: Gabriel(but not really) Bacarin #10873351
	SCC0201 - ICC 2
	Trabalho 3 - Simulador de Escalonador de Processos
*/
#include<stdio.h>
#include<stdlib.h>
#include"lista.h"

// Função que lê as entradas da entrada padrão e adiciona elas na lista
void lerEntradas(lst *lista) {
	int cod, tempoi, quantum, prioridade;
	char prox;
	do {
		scanf("%d %d %d %d", &cod, &tempoi, &quantum, &prioridade);
		prox = fgetc(stdin);
		inserirProcesso(lista, cod, tempoi, quantum, prioridade);
	}while(prox != EOF);
}

int main() {
	lst *lista = novaLista();
	lerEntradas(lista);
	rodarSimulacao(lista);
	//imprimirLista(lista);
	limparLista(lista);

	return 0;
}