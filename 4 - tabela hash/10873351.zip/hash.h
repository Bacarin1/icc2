/*
	Nome: Bacarin #10873351
	SCC0201 - ICC 2
	Trabalho 4 - Tabela Hash
*/
typedef struct node node;

struct node {
	char *palavra;
	node *prox;
};

typedef struct hashTable {
	int qtdIndices;
	node **indices;
}hash;


hash *criarHashTable(int qtdIndices);
node *buscarNode(hash *table, int i, char *buscado);
int inserirNode(hash *table, int i, char *palavra);
int deletarNode(hash *table, int i, char *palavra);
void get(hash *table, int i);
void desalocarHashTable(hash *table);