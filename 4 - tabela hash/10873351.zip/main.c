/*
	Nome: Bacarin #10873351
	SCC0201 - ICC 2
	Trabalho 4 - Tabela Hash

	feliz natal gente, obg pelo semeste :)
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include"hash.h"

//constantes usadas na criação do hash
#define P 1000000007
#define X 263

//função para ler uma palavra da entrada, palavra acaba ao achar caracter
//end ou EOF
char *lerPalavra(char end) {
	char *palavra = malloc(0);
	int tamPalavra = 1;

	while(1) {
		char entrada;
		entrada = fgetc(stdin);

		if(entrada == '\r')
			continue;

		if(entrada != end && entrada != EOF) {
			tamPalavra++;
			palavra = realloc(palavra, tamPalavra * sizeof(char));
			palavra[tamPalavra - 2] = entrada;
		}
		else {
			palavra[tamPalavra - 1] = '\0';
			break;
		}
	}

	return palavra;
}

//função para gerar o hash usado nos índices da tabela
int gerarHash(char *palavra, int m) {
	int s = strlen(palavra);
	long long int sum = 0;
	for(int i = 0; i < s; i++) {
		sum += palavra[i] * pow(X, i);
	}

	sum = sum % P;
	sum = sum % m;
		
	//printf("%d\n", sum);
	return sum;
}

int main() {
	int m, qtdInstrucoes;
	scanf("%d %d ", &m, &qtdInstrucoes);

	hash *table = criarHashTable(m);

	for(int i = 0; i < qtdInstrucoes; i++) {
		char *comando = lerPalavra(' '); //lendo o comando

		if(strcmp(comando, "add") == 0) { // comando de inserir
			char *palavra = lerPalavra('\n');
			int hash = gerarHash(palavra, m);
			inserirNode(table, hash, palavra);
			free(palavra);
		}
		else if(strcmp(comando, "del") == 0) { // deletar uma palavra
			char *palavra = lerPalavra('\n');
			int hash = gerarHash(palavra, m);
			deletarNode(table, hash, palavra);
			free(palavra);
		}
		else if(strcmp(comando, "get") == 0) { // imprimir todas do indice
			int indice;
			scanf("%d ", &indice);
			get(table, indice);
		}
		else { // check para ver se palavra está na tabela ou não
			char *palavra = lerPalavra('\n');
			int hash = gerarHash(palavra, m);
			node *retorno = buscarNode(table, hash, palavra);
			if(retorno != NULL && strcmp(retorno->palavra, palavra) == 0) {
				printf("sim\n");
			}
			else {
				printf("não\n");
			}
			free(palavra);
		}

		free(comando);
	}

	desalocarHashTable(table);

	return 0;
}