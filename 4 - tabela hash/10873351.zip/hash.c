/*
	Nome: Bacarin #10873351
	SCC0201 - ICC 2
	Trabalho 4 - Tabela Hash
*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"hash.h"

// cria uma nova hashtable vazia e retorna ela
hash *criarHashTable(int qtdIndices) {
	hash *table = malloc(sizeof(hash));

	table->qtdIndices = qtdIndices;
	table->indices = malloc(qtdIndices * sizeof(void *));
	for(int i = 0; i < qtdIndices; i++) { // criando os espaços para cada índice
		table->indices[i] = NULL;
	}

	return table;
}

//busca um node da hashtable baseado no nome e no int i, que é o índice
//do hash, tentando se aproximar de O(1)
node *buscarNode(hash *table, int i, char *buscado) {
	node *buscar = table->indices[i];
	if(buscar == NULL) {
		return buscar;
	}

	while(buscar->prox != NULL && strcmp(buscar->palavra, buscado) != 0) {
		buscar = buscar->prox;
	}

	return buscar;
}

//cria e retorna um novo node para ser inserido na hashtable
node *novoNo(char *palavra) {
	node *no = malloc(sizeof(node));
	no->palavra = malloc(strlen(palavra) * sizeof(char));
	strcpy(no->palavra, palavra);
	no->prox = NULL;
	return no;
}

//insere um novo node, sempre logo no início da lista do índice i
//insere só caso ainda não exista a palavra
int inserirNode(hash *table, int i, char *palavra) {
	node *buscar = buscarNode(table, i, palavra);
	if(buscar != NULL) {
		if(strcmp(buscar->palavra, palavra) == 0) {
			return -1;
		}
	}

	node *inserir = novoNo(palavra);
	node *prox = table->indices[i];

	table->indices[i] = inserir;
	inserir->prox = prox;

	return 0;
}

//deleta um node dado da lista do índice i caso ele exista
int deletarNode(hash *table, int i, char *palavra) {
	node *ant = NULL;
	node *percorre = table->indices[i];

	while(percorre != NULL && strcmp(percorre->palavra, palavra) != 0) {
		ant = percorre;
		percorre = percorre->prox;
	}

	if(percorre == NULL)
		return -1;

	if(strcmp(percorre->palavra, palavra) == 0) {
		if(ant == NULL) {
			table->indices[i] = percorre->prox;
			free(percorre->palavra);
			free(percorre);
			return 0;
		}
		else {
			ant->prox = percorre->prox;
			free(percorre->palavra);
			free(percorre);
			return 0;
		}
	}
	return -1;
}

//imprime todos os nodes de uma lista de índice i
void get(hash *table, int i) {
	node *percorre = table->indices[i];

	while(percorre != NULL) {
		printf("%s ", percorre->palavra);
		percorre = percorre->prox;
	}
	printf("\n");
}

//desaloca a memória usada na hashtable e todos os seus itens
void desalocarHashTable(hash *table) {
	for(int i = 0; i < table->qtdIndices; i++) {
		node *percorre = table->indices[i];
		
		while(percorre != NULL) {
			table->indices[i] = percorre->prox;
			free(percorre->palavra);
			free(percorre);
			percorre = table->indices[i];
		}

		free(table->indices[i]);
	}
	free(table->indices);
	free(table);
}